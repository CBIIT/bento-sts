'use strict';


/**
 * Get MDB entity with specified nanoid
 *
 * id String Nanoid (6 character unique string)
 * returns Entity
 **/
exports.idIdGET = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

