'use strict';


/**
 * Retrieve a specified node from a model
 *
 * modelHandle String Handle (\\'name\\') of model (use /models to find available handles) 
 * nodeHandle String Handle (\\'name\\') of node (use /model/{modelHandle}/nodes to find available nodes 
 * returns Node
 **/
exports.modelModelHandleNodeNodeHandleGET = function(modelHandle,nodeHandle) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get number of  properties for specified node
 *
 * modelHandle String Handle (\\'name\\') of model (use /models to find available handles) 
 * nodeHandle String Handle (\\'name\\') of node (use /model/{modelHandle}/nodes to find available nodes 
 * returns Object
 **/
exports.modelModelHandleNodeNodeHandlePropertiesCountGET = function(modelHandle,nodeHandle) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get all properties for specified node
 *
 * modelHandle String Handle (\\'name\\') of model (use /models to find available handles) 
 * nodeHandle String Handle (\\'name\\') of node (use /model/{modelHandle}/nodes to find available nodes 
 * skip Integer Pagination - number of items to skip  (optional)
 * limit Integer Pagination - number of items to return  (optional)
 * returns Object
 **/
exports.modelModelHandleNodeNodeHandlePropertiesGET = function(modelHandle,nodeHandle,skip,limit) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve a specified property from a model
 *
 * modelHandle String Handle (\\'name\\') of model (use /models to find available handles) 
 * nodeHandle String Handle (\\'name\\') of node (use /model/{modelHandle}/nodes to find available nodes 
 * propHandle String Handle (\\'name\\') of property (use /model/{modelHandle}/node/{nodeHandle}/properties to find available properties 
 * returns Property
 **/
exports.modelModelHandleNodeNodeHandlePropertyPropHandleGET = function(modelHandle,nodeHandle,propHandle) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve a specified term from a property\\'s acceptable value set 
 *
 * modelHandle String Handle (\\'name\\') of model (use /models to find available handles) 
 * nodeHandle String Handle (\\'name\\') of node (use /model/{modelHandle}/nodes to find available nodes 
 * propHandle String Handle (\\'name\\') of property (use /model/{modelHandle}/node/{nodeHandle}/properties to find available properties 
 * termValue String String representation (\\'value\\') of the term (use /model/{modelHandle}/node/{nodeHandle}/property/{propHandle}/terms to find available terms 
 * returns Object
 **/
exports.modelModelHandleNodeNodeHandlePropertyPropHandleTermTermValueGET = function(modelHandle,nodeHandle,propHandle,termValue) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get number of  properties for specified node
 *
 * modelHandle String Handle (\\'name\\') of model (use /models to find available handles) 
 * nodeHandle String Handle (\\'name\\') of node (use /model/{modelHandle}/nodes to find available nodes 
 * propHandle String Handle (\\'name\\') of property (use /model/{modelHandle}/node/{nodeHandle}/properties to find available properties 
 * returns Object
 **/
exports.modelModelHandleNodeNodeHandlePropertyPropHandleTermsCountGET = function(modelHandle,nodeHandle,propHandle) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get the terms (acceptable values) for specified property, if applicable to property 
 *
 * modelHandle String Handle (\\'name\\') of model (use /models to find available handles) 
 * nodeHandle String Handle (\\'name\\') of node (use /model/{modelHandle}/nodes to find available nodes 
 * propHandle String Handle (\\'name\\') of property (use /model/{modelHandle}/node/{nodeHandle}/properties to find available properties 
 * skip Integer Pagination - number of items to skip  (optional)
 * limit Integer Pagination - number of items to return  (optional)
 * returns Object
 **/
exports.modelModelHandleNodeNodeHandlePropertyPropHandleTermsGET = function(modelHandle,nodeHandle,propHandle,skip,limit) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get number of nodes for specified model
 *
 * modelHandle String Handle (\\'name\\') of model (use /models to find available handles) 
 * returns Object
 **/
exports.modelModelHandleNodesCountGET = function(modelHandle) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get all nodes for specified model
 *
 * modelHandle String Handle (\\'name\\') of model (use /models to find available handles) 
 * skip Integer Pagination - number of items to skip  (optional)
 * limit Integer Pagination - number of items to return  (optional)
 * returns Object
 **/
exports.modelModelHandleNodesGET = function(modelHandle,skip,limit) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

