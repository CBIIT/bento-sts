'use strict';


/**
 * Get number of entities tagged by key:value
 *
 * key String Tag node key (string)
 * value String Tag node value (string)
 * skip Integer Pagination - number of items to skip  (optional)
 * limit Integer Pagination - number of items to return  (optional)
 * returns Object
 **/
exports.tagKeyValueEntitiesCountGET = function(key,value,skip,limit) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get list of entities tagged by key:value
 *
 * key String Tag node key (string)
 * value String Tag node value (string)
 * returns Object
 **/
exports.tagKeyValueEntitiesGET = function(key,value) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get list of tags having specified tag key
 *
 * key String Tag node key (string)
 * returns Object
 **/
exports.tagKeyValuesGET = function(key) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

