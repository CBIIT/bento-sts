'use strict';

var utils = require('../utils/writer.js');
var Model = require('../service/ModelService');

module.exports.modelModelHandleNodeNodeHandleGET = function modelModelHandleNodeNodeHandleGET (req, res, next) {
  var modelHandle = req.swagger.params['modelHandle'].value;
  var nodeHandle = req.swagger.params['nodeHandle'].value;
  Model.modelModelHandleNodeNodeHandleGET(modelHandle,nodeHandle)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.modelModelHandleNodeNodeHandlePropertiesCountGET = function modelModelHandleNodeNodeHandlePropertiesCountGET (req, res, next) {
  var modelHandle = req.swagger.params['modelHandle'].value;
  var nodeHandle = req.swagger.params['nodeHandle'].value;
  Model.modelModelHandleNodeNodeHandlePropertiesCountGET(modelHandle,nodeHandle)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.modelModelHandleNodeNodeHandlePropertiesGET = function modelModelHandleNodeNodeHandlePropertiesGET (req, res, next) {
  var modelHandle = req.swagger.params['modelHandle'].value;
  var nodeHandle = req.swagger.params['nodeHandle'].value;
  var skip = req.swagger.params['skip'].value;
  var limit = req.swagger.params['limit'].value;
  Model.modelModelHandleNodeNodeHandlePropertiesGET(modelHandle,nodeHandle,skip,limit)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.modelModelHandleNodeNodeHandlePropertyPropHandleGET = function modelModelHandleNodeNodeHandlePropertyPropHandleGET (req, res, next) {
  var modelHandle = req.swagger.params['modelHandle'].value;
  var nodeHandle = req.swagger.params['nodeHandle'].value;
  var propHandle = req.swagger.params['propHandle'].value;
  Model.modelModelHandleNodeNodeHandlePropertyPropHandleGET(modelHandle,nodeHandle,propHandle)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.modelModelHandleNodeNodeHandlePropertyPropHandleTermTermValueGET = function modelModelHandleNodeNodeHandlePropertyPropHandleTermTermValueGET (req, res, next) {
  var modelHandle = req.swagger.params['modelHandle'].value;
  var nodeHandle = req.swagger.params['nodeHandle'].value;
  var propHandle = req.swagger.params['propHandle'].value;
  var termValue = req.swagger.params['termValue'].value;
  Model.modelModelHandleNodeNodeHandlePropertyPropHandleTermTermValueGET(modelHandle,nodeHandle,propHandle,termValue)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.modelModelHandleNodeNodeHandlePropertyPropHandleTermsCountGET = function modelModelHandleNodeNodeHandlePropertyPropHandleTermsCountGET (req, res, next) {
  var modelHandle = req.swagger.params['modelHandle'].value;
  var nodeHandle = req.swagger.params['nodeHandle'].value;
  var propHandle = req.swagger.params['propHandle'].value;
  Model.modelModelHandleNodeNodeHandlePropertyPropHandleTermsCountGET(modelHandle,nodeHandle,propHandle)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.modelModelHandleNodeNodeHandlePropertyPropHandleTermsGET = function modelModelHandleNodeNodeHandlePropertyPropHandleTermsGET (req, res, next) {
  var modelHandle = req.swagger.params['modelHandle'].value;
  var nodeHandle = req.swagger.params['nodeHandle'].value;
  var propHandle = req.swagger.params['propHandle'].value;
  var skip = req.swagger.params['skip'].value;
  var limit = req.swagger.params['limit'].value;
  Model.modelModelHandleNodeNodeHandlePropertyPropHandleTermsGET(modelHandle,nodeHandle,propHandle,skip,limit)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.modelModelHandleNodesCountGET = function modelModelHandleNodesCountGET (req, res, next) {
  var modelHandle = req.swagger.params['modelHandle'].value;
  Model.modelModelHandleNodesCountGET(modelHandle)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.modelModelHandleNodesGET = function modelModelHandleNodesGET (req, res, next) {
  var modelHandle = req.swagger.params['modelHandle'].value;
  var skip = req.swagger.params['skip'].value;
  var limit = req.swagger.params['limit'].value;
  Model.modelModelHandleNodesGET(modelHandle,skip,limit)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
