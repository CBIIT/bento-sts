'use strict';

var utils = require('../utils/writer.js');
var Models = require('../service/ModelsService');

module.exports.modelsCountGET = function modelsCountGET (req, res, next) {
  Models.modelsCountGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.modelsGET = function modelsGET (req, res, next) {
  Models.modelsGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
