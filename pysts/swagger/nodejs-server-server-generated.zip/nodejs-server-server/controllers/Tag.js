'use strict';

var utils = require('../utils/writer.js');
var Tag = require('../service/TagService');

module.exports.tagKeyValueEntitiesCountGET = function tagKeyValueEntitiesCountGET (req, res, next) {
  var key = req.swagger.params['key'].value;
  var value = req.swagger.params['value'].value;
  var skip = req.swagger.params['skip'].value;
  var limit = req.swagger.params['limit'].value;
  Tag.tagKeyValueEntitiesCountGET(key,value,skip,limit)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.tagKeyValueEntitiesGET = function tagKeyValueEntitiesGET (req, res, next) {
  var key = req.swagger.params['key'].value;
  var value = req.swagger.params['value'].value;
  Tag.tagKeyValueEntitiesGET(key,value)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.tagKeyValuesGET = function tagKeyValuesGET (req, res, next) {
  var key = req.swagger.params['key'].value;
  Tag.tagKeyValuesGET(key)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
