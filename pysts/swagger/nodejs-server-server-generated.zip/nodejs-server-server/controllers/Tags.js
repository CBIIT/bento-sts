'use strict';

var utils = require('../utils/writer.js');
var Tags = require('../service/TagsService');

module.exports.tagsCountGET = function tagsCountGET (req, res, next) {
  Tags.tagsCountGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.tagsGET = function tagsGET (req, res, next) {
  Tags.tagsGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
